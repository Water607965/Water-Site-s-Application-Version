//
//  waterlordApp.swift
//  waterlord
//
//  Created by Water on 1/20/24.
//

import SwiftUI

@main
struct waterlordApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
