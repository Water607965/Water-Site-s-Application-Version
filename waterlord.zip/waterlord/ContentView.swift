import SwiftUI
import UserNotifications

struct ContentView: View {
    var body: some View {
        GeometryReader { geo in
            ZStack {
                Image("wa")
                    .resizable()
                    .scaledToFill()
                    .edgesIgnoringSafeArea(.all)
                    .frame(width: geo.size.width, height: geo.size.height, alignment: .center)

                VStack(alignment: .center) {
                    Image("was")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .foregroundColor(Color.red)
                        .padding(.top)
                        .imageScale(.small)
                        .foregroundStyle(.tint)

                    Slider(value: .constant(1))

                    Image(systemName: "drop.circle.fill")
                        .foregroundColor(Color.red)
                        .padding(.bottom)

                    Text("Welcome to Water!")
                        .blur(radius: 0)
                        .font(.headline)
                        .brightness(0.6)
                        .fontWeight(.heavy)
                        .foregroundColor(Color.blue)
                        .multilineTextAlignment(.leading)
                        .padding()

                    Slider(value: .constant(1))

                    Image(systemName: "star.fill")
                        .foregroundColor(Color.red)

                    Text("Known For & Professions: I am known primarily for being known as Water, where I hack ethically in Linux, my work there, and my general interests.")
                        .font(.body)
                        .fontWeight(.heavy)
                        .foregroundColor(Color.yellow)
                        .multilineTextAlignment(.center)
                        .padding(.vertical, 14.0)
                        .brightness(0.5)
                        .frame(maxWidth: .infinity)
                        .multilineTextAlignment(.center)

                    Image("wa")
                        .resizable()
                        .font(.caption)
                        .aspectRatio(contentMode: .fit)
                        .padding(.top)
                        .frame(width: 1.0)
                        .fontWeight(.heavy)
                        .foregroundColor(Color.orange)

                    Slider(value: .constant(1))

                    Image(systemName: "point.3.filled.connected.trianglepath.dotted")
                        .aspectRatio(contentMode: .fill)
                        .foregroundColor(Color.red)
                        .padding(.bottom)
                        .frame(width: 0.0)

                    Text("Connections: https://connections.h2owater.xyz")
                        .font(.headline)
                        .fontWeight(.heavy)
                        .foregroundColor(Color.green)
                        .multilineTextAlignment(.center)
                        .padding(.top, 0.0)
                        .brightness(0.5)

                    Slider(value: .constant(1))

                    Image(systemName: "desktopcomputer")
                        .aspectRatio(contentMode: .fill)
                        .foregroundColor(Color.red)
                        .padding(.bottom)
                        .frame(width: 0.0)

                    Text("Interactive Python Shell Scripts (GitHub): https://github.com/Water607965/Water")
                        .font(.headline)
                        .fontWeight(.heavy)
                        .foregroundColor(Color.yellow)
                        .multilineTextAlignment(.center)
                        .padding(.top, 0.0)
                        .brightness(0.5)
                        .frame(maxWidth: .infinity)
                        .multilineTextAlignment(.center)

                    Slider(value: .constant(1))

                    Image(systemName: "exclamationmark.triangle.fill")
                        .aspectRatio(contentMode: .fill)
                        .foregroundColor(Color.red)
                        .padding(.bottom)
                        .frame(width: 0.0)

                    Text("Hint: Turn on dark mode if you have light mode and you'll see the hidden white box down below!")
                        .font(.headline)
                        .fontWeight(.heavy)
                        .foregroundColor(Color.red)
                        .multilineTextAlignment(.center)
                        .padding(.top, 0.0)
                        .brightness(0.5)
                        .frame(maxWidth: .infinity)
                        .multilineTextAlignment(.center)

                    SecureField("Type anything you want.", text: .constant(""))
                        .accessibilityAddTraits([.isButton])
                        .accessibilityHidden(true)
                        .padding(.bottom)
                        .font(.headline)
                        .brightness(1)
                        .blur(radius: 1)
                        .padding()
                    Slider(value: .constant(1))

                    Image(systemName: "info.circle.fill")

                        .aspectRatio(contentMode: .fill)
                        .foregroundColor(Color.red)
                        .padding(.bottom)
                        .frame(width: 0.0)

                    Text("Copyright © 2024 Water. All rights reserved.")
                        .font(.headline)
                        .fontWeight(.heavy)
                        .foregroundColor(Color.green)
                        .multilineTextAlignment(.center)
                        .padding(.bottom, 0.0)
                        .brightness(0.5)
                        .frame(maxWidth: .infinity)
                        .multilineTextAlignment(.center)
                    Button("Quit App") {
                        exit(0)
                            
                    }
                    .padding(.bottom)

                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

